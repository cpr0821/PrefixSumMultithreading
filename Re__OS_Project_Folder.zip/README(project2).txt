README:
Orlando Garcia - osg150030
Camryn Rogers - cpr170030

Instructions to compile and run:
Open a Linux terminal
Compile the C++ file
	g++ cps.cpp -pthread

Include the following command line arguments:
(1) Size of array
(2) Input file name (inluding .txt extension)
(3) Output file name (inluding .txt extension)
(4) Number of threads to be used

./a.out [numElements] [inputFile] [outputFile] [numThreads]

Example Test Cases::
NOTE: num.txt, output.txt, num2.txt, num3.txt, num4.txt are all located in submission folder

g++ cps.cpp -pthread	
./a.out 16 num.txt output.txt 4

./a.out 315 num2.txt output.txt 5